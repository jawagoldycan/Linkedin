package LinkedinJobApply.JobApllication;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageObjects.AlreadyAppliedJobPopUp;
import PageObjects.HomePage;
import PageObjects.ApplicationSubmissionPopup;
import PageObjects.SearchJobPage;
import PageObjects.SignInCredentials;
import PageObjects.SignInPage;
import PageObjects.VerifyInfo;
import resources.Base;

public class QAJobApplication extends Base{
	
	public SearchJobPage jobPage;
	
	@BeforeTest
	public void driverInitialization() throws IOException
	{
		driver=InitializeDriver();
	}
	
	@Test
	public void applyTestingJob() throws InterruptedException
	{
		//Invoke the required url
		driver.get(url);
		
		//Click on the sign in button
		SignInPage signIn =new SignInPage(driver);
		signIn.getSignIn().click();
		
		//Pass the user credentials and do the sign in
		SignInCredentials cred = new SignInCredentials(driver);
		cred.getUserName().sendKeys(email);
		cred.getPassword().sendKeys(password);
		cred.getSignIn().click();
		
		/*//Verify the user credentials
		VerifyInfo info = new VerifyInfo();
	if(Assert.assertTrue(info.getTitle().isDisplayed()))
	{
		
	}*/
		
		//Robotic verification
		/*RoboticMessageVerification rob = new RoboticMessageVerification(driver);
		String robMessage = rob.getNotRobot().getText();
		Thread.sleep(5000);
		if(Assert.assertEquals(robMessage, expected);
				{
			rob.getCheckbox().click();
				}*/
		
		//Click on Jobs tab
		HomePage hp = new HomePage(driver);
		hp.getJobs().click();
		
		//Search the jobs and select the same
		jobPage = new SearchJobPage(driver);
		//jobPage.getJobType().sendKeys("testing automation");
		jobPage.getlocation().sendKeys("data");
		jobPage.getSearch().click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int size = jobPage.getJobList().size();
		System.out.println("size is-----"+size);
		System.out.println("size of boxcount ---"+jobPage.getBoxCount().size());
		for(int x=0; x<jobPage.getBoxCount().size(); x++)
		{
			
		for(int i=0; i<size; i++)
		{
			
			//Traverse through each job index wise
			jobPage.getTitle().get(i).click();
			System.out.println("before if1");
			
			//Get the button name from the right side of job description to validate whether its "Easy Apply"
			if(jobPage.getEasyApply() == null)
			{
				System.out.println("Easy apply not displayed");
				continue;
			}
			if(jobPage.getEasyApply().isDisplayed())
			{
				System.out.println("inside if1");
			String text= jobPage.getEasyApply().getText();
			System.out.println(text);
			if(text.contains("Easy"))
			{
				System.out.println("hello1");
				jobPage.getEasyApply().click();
				System.out.println("hello2");
				String emailText = jobPage.getEmail().getText();
				String phoneText = jobPage.getPhone().getText();
				if(emailText.isEmpty())
				{
					System.out.println("hello3");
					jobPage.getEmail().sendKeys(email);
				}
				/*if(phoneText.isEmpty())
				{
					jobPage.getPhone().sendKeys("15146901424");
				}*/
				if(jobPage.getSubmitCount().size()>0)
				{
					System.out.println("inside getSubmitCount if ");
				jobPage.getSubmit().click();
				System.out.println("leaving getSubmitCount if ");
				}
				AlreadyAppliedJobPopUp popUp = new AlreadyAppliedJobPopUp(driver);
				//Validate whether popup is displayed on the page
				AssertJUnit.assertTrue(popUp.getClose().isDisplayed());
				if(popUp.getCloseSize()>0)
				{    
					popUp.getClose().click();
				}
				
				ApplicationSubmissionPopup appPopup = new ApplicationSubmissionPopup(driver);
				/*Assert.assertTrue(appPopup.getClosePopUp().isDisplayed());
				if(appPopup.getClosePopUpCount()>0)
				{    
					appPopup.getClosePopUp().click();
				}*/
				if (appPopup.getSubmissionMessage().isDisplayed())
				{
					appPopup.getClosePopUp().click();
				}
			}
			}
			System.out.println(i);
		}
		System.out.println("hello1");
		jobPage.getBoxCount().get(x).click();
		System.out.println("Value of x -- "+x);
		}
	}

	//li[class='artdeco-pagination__indicator artdeco-pagination__indicator--number ']
}
