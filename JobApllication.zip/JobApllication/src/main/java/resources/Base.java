package resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Base {
	
	public WebDriver driver;
	public Properties prop;
	public String email = null;
	public String password = null;
	public String url = null;
	public String browserName =null;
	public String jobType =null;
	
	public WebDriver InitializeDriver() throws IOException
	{
		/*FileInputStream fis = new FileInputStream("/Users/runnr/JobApllication/src/main/java/resources/data.properties");
		prop = new Properties();
		prop.load(fis);
		browserName= prop.getProperty("browser"); */
		
		email=  System.getProperty("email");
		password=  System.getProperty("password");
		url=  System.getProperty("url");
		jobType=  System.getProperty("jobType");
		browserName=  System.getProperty("browserName");
		if(browserName.contains("chrome"))
		{
			ChromeOptions option= new ChromeOptions();
			if(browserName.contains("headless"))
			{
				option.addArguments("--headless");
			}
			driver = new ChromeDriver(option);
		}
		//if(BROWSER.equalsIgnoreCase("Firefox"))
		else if (browserName.contains("firefox"))
		{
			driver = new FirefoxDriver();
		}
		else if (browserName.contains("safari"))
		{
			driver = new SafariDriver();
		}
		else if (browserName.contains("Internet Explorer"))
		{
			driver = new InternetExplorerDriver();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
		return driver;
	}

}
