package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class ApplicationSubmissionPopup extends Base{
	
	By submissionMessage = By.xpath("//h3[text(),'Your application has been submitted!']");
	By closePopUp = By.xpath("//button[@class='artdeco-modal__dismiss artdeco-button artdeco-button--circle artdeco-button--muted artdeco-button--2 artdeco-button--tertiary ember-view']");
	
	public ApplicationSubmissionPopup(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver= driver;
	}
	public WebElement getSubmissionMessage()
	{
		return driver.findElement(submissionMessage);
	}
	public int getClosePopUpCount()
	{
		return driver.findElements(closePopUp).size();
	}
	public WebElement getClosePopUp()
	{
		return driver.findElement(closePopUp);
	}

}
