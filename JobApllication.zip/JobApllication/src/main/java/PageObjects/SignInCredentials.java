package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class SignInCredentials extends Base{
	
	By userName=By.id("username");
	By password=By.id("password");
	By signIn = By.xpath("//button[text()='Sign in']");
	
	public SignInCredentials(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public WebElement getUserName()
	{
		return driver.findElement(userName);
	}
	public WebElement getPassword()
	{
		return driver.findElement(password);
	}
	public WebElement getSignIn()
	{
		return driver.findElement(signIn);
	}

}
