package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import resources.Base;

public class VerifyInfo extends Base{
	
	By title = By.xpath("//h2[text()='Is this information correct?']");
	By done = By.xpath("//button[@class='primary-action']");
	
	
	public WebElement getTitle()
	{
		return driver.findElement(title);
	}
	
	public WebElement clickDone()
	{
		return driver.findElement(done);
	}
	
	

}
