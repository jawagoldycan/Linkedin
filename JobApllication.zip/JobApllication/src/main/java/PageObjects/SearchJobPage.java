package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class SearchJobPage extends Base
{
	
	By jobType = By.cssSelector("input[id*='jobs-search-box-keyword-id-ember']");
	By location = By.cssSelector("input[id*='jobs-search-box-location-id-ember']");
	By search =  By.xpath("//button[text()='Search']");
	By jobList = By.xpath("//ul[@class='jobs-search-results__list artdeco-list']/li");
	By easyApply = By.xpath("//div[@class='jobs-details-top-card__container']/div[2]/div[2]/div[1]/div[3]/div[1]/button[1]/span[1]");
	By title= By.xpath("//ul[@class='jobs-search-results__list artdeco-list']/li/div/artdeco-entity-lockup/artdeco-entity-lockup-content/h3/a");
	By submit = By.xpath("//span[text()='Submit application']");
	By message = By.cssSelector("span.artdeco-inline-feedback__message");
	By email = By.id("apply-form-email-select");
	By phone = By.id("apply-form-phone-input");
	By boxCount = By.xpath("//ul[@class='artdeco-pagination__pages artdeco-pagination__pages--number']/li");
	
	public SearchJobPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public WebElement getJobType()
	{
		return driver.findElement(jobType);
	}
	public WebElement getlocation()
	{
		return driver.findElement(location);
	}
	public WebElement getSearch()
	{
		return driver.findElement(search);
	}
	public List<WebElement> getJobList()
	{
		return driver.findElements(jobList);
	}
	public List<WebElement> getTitle()
	{
		return driver.findElements(title);
	}
	public WebElement getEasyApply()
	{
		try {
			return driver.findElement(easyApply);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public WebElement getSubmit()
	{
		return driver.findElement(submit);
	}
	public List<WebElement> getSubmitCount()
	{
		return driver.findElements(submit);
	}
	public WebElement getMessageAlreadyApplied()
	{
		return driver.findElement(message);
	}
	public WebElement getEmail()
	{
		return driver.findElement(email);
	}
	public WebElement getPhone()
	{
		return driver.findElement(phone);
	}
	public List<WebElement> getBoxCount()
	{
		return driver.findElements(boxCount);
	}
	public WebElement getNextBox()
	{
		return driver.findElement(boxCount);
	}
	//ul[@class='jobs-search-results__list artdeco-list']/li/div/artdeco-entity-lockup/artdeco-entity-lockup-content
}
