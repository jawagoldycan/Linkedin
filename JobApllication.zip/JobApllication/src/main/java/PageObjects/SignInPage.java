package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class SignInPage extends Base{
	
By signIn = By.xpath("//a[text()='Sign in']");
	
	public SignInPage(WebDriver driver) {
	// TODO Auto-generated constructor stub
		this.driver=driver;
}

	public WebElement getSignIn()
	{
		return driver.findElement(signIn);
	}

}
