package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class AlreadyAppliedJobPopUp extends Base{
	
	By message = By.xpath("//div[@class='jobs-apply-form__error-message t-14 t-black t-bold pb2']");
	By close = By.xpath("//div[@class='jobs-apply-form__footer-buttons display-flex']/button[1]/span[1]");
	
	public AlreadyAppliedJobPopUp(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	public String getMessage()
	{
		return driver.findElement(message).getText();
	}
	public WebElement getClose()
	{
		return driver.findElement(close);
	}
	public int getCloseSize()
	{
		return driver.findElements(close).size();
	}
}
