package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;

public class HomePage extends Base{
	
By jobs = By.id("jobs-tab-icon");
	
	public HomePage(WebDriver driver) {
	// TODO Auto-generated constructor stub
		this.driver=driver;
}

	public WebElement getJobs()
	{
		return driver.findElement(jobs);
	}

}
